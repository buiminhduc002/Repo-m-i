# Chẵn/Lẻ Game App

Ứng dụng web chơi game Chẵn/Lẻ + tích hợp nạp tiền MoMo (giả lập nếu chưa có khóa).

## Triển khai local

```bash
npm install
cp .env.example .env      # chỉnh sửa các biến nếu cần
node even_odd_game_app.js
```

Truy cập http://localhost:3000

## Triển khai Render

1. Tạo repo GitHub, đẩy mã nguồn này.
2. Trên Render.com:
   - New > Web Service > Connect your repository
   - Environment: Node
   - Build Command: `npm install`
   - Start Command: `node even_odd_game_app.js`
   - Add Environment Variables giống file `.env.example`
3. Deploy -> Thưởng thức!

## MoMo thật

- Cần đăng ký tài khoản MoMo Business để lấy `PARTNER_CODE`, `ACCESS_KEY`, `SECRET_KEY`.
- Cập nhật `MOMO_*` trong `.env`
- Khi chưa có, app sẽ giả lập việc cộng tiền ngay khi nạp.


require('dotenv').config();
const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');
const axios = require('axios');
const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.PORT || 3000;

// ---------- DATABASE ----------
const db = new sqlite3.Database('db.sqlite');
db.serialize(() => {
  db.run(\`CREATE TABLE IF NOT EXISTS users(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE,
      password_hash TEXT,
      balance INTEGER DEFAULT 0
  )\`);
  db.run(\`CREATE TABLE IF NOT EXISTS transactions(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      trans_id TEXT,
      amount INTEGER,
      status TEXT,
      type TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )\`);
});

// ---------- MIDDLEWARE ----------
app.use(bodyParser.urlencoded({ extended: true }));
app.use(
  session({
    secret: process.env.SESSION_SECRET || 'supersecret',
    resave: false,
    saveUninitialized: false,
    cookie: { httpOnly: true },
  })
);

app.use((req, res, next) => {
  res.locals.user = req.session.user;
  next();
});

function requireLogin(req, res, next) {
  if (!req.session.user) return res.redirect('/login');
  next();
}

// ---------- ROUTES ----------
app.get('/', (req, res) => {
  if (res.locals.user) {
    return res.send(\`<!doctype html>
      <h1>Chào \${res.locals.user.username}</h1>
      <p>Số dư: <b>\${res.locals.user.balance}</b></p>
      <a href="/deposit">Nạp tiền MoMo</a> |
      <a href="/play">Chơi Chẵn/Lẻ</a> |
      <a href="/logout">Đăng xuất</a>
    \`);
  }
  res.send(\`<!doctype html>
    <h1>Game Chẵn/Lẻ</h1>
    <a href="/register">Đăng ký</a> | <a href="/login">Đăng nhập</a>
  \`);
});

// REGISTER
app.get('/register', (req, res) => {
  res.send(\`<!doctype html>
    <h2>Đăng ký</h2>
    <form method="post" action="/register">
      <input name="username" required placeholder="Tên đăng nhập" /><br>
      <input type="password" name="password" required placeholder="Mật khẩu" /><br>
      <button type="submit">Tạo tài khoản</button>
    </form>
  \`);
});

app.post('/register', async (req, res) => {
  const { username, password } = req.body;
  const hash = await bcrypt.hash(password, 10);
  db.run(
    'INSERT INTO users(username, password_hash) VALUES (?, ?)',
    [username, hash],
    function (err) {
      if (err) return res.send('❌ Tên tài khoản đã tồn tại! <a href="/register">Quay lại</a>');
      res.redirect('/login');
    }
  );
});

// LOGIN
app.get('/login', (req, res) => {
  res.send(\`<!doctype html>
    <h2>Đăng nhập</h2>
    <form method="post" action="/login">
      <input name="username" required placeholder="Tên đăng nhập" /><br>
      <input type="password" name="password" required placeholder="Mật khẩu" /><br>
      <button type="submit">Đăng nhập</button>
    </form>
  \`);
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  db.get('SELECT * FROM users WHERE username = ?', [username], async (err, user) => {
    if (!user) return res.send('❌ Không tìm thấy tài khoản! <a href="/login">Thử lại</a>');
    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.send('❌ Sai mật khẩu! <a href="/login">Thử lại</a>');
    req.session.user = { id: user.id, username, balance: user.balance };
    res.redirect('/');
  });
});

// LOGOUT
app.get('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/'));
});

// DEPOSIT (simulate if no MoMo keys)
app.get('/deposit', requireLogin, (req, res) => {
  res.send(\`<!doctype html>
    <h2>Nạp tiền MoMo</h2>
    <form method="post" action="/deposit">
      <input type="number" name="amount" min="1000" required /> <br>
      <button type="submit">Tạo giao dịch</button>
    </form>
    <a href="/">Trang chủ</a>
  \`);
});

app.post('/deposit', requireLogin, async (req, res) => {
  const amount = parseInt(req.body.amount, 10);
  if (isNaN(amount) || amount < 1000) return res.send('❌ Số tiền không hợp lệ!');
  const orderId = Date.now().toString();
  // If no MoMo keys -> instant success
  if (!process.env.MOMO_PARTNER_CODE) {
    db.run(
      'INSERT INTO transactions(user_id, trans_id, amount, status, type) VALUES (?,?,?,?,?)',
      [req.session.user.id, orderId, amount, 'success', 'deposit'],
      () => {
        db.run('UPDATE users SET balance = balance + ? WHERE id = ?', [amount, req.session.user.id]);
        res.redirect('/');
      }
    );
    return;
  }
  res.send('Tính năng thanh toán MoMo thật cần cấu hình thêm.');
});

// GAME
app.get('/play', requireLogin, (req, res) => {
  db.get('SELECT balance FROM users WHERE id = ?', [req.session.user.id], (err, row) => {
    const balance = row.balance;
    res.send(\`<!doctype html>
      <h2>Chẵn/Lẻ</h2>
      <p>Số dư hiện tại: <b>\${balance}</b></p>
      <form method="post" action="/play">
        <label><input type="radio" name="choice" value="even" required /> Chẵn</label>
        <label><input type="radio" name="choice" value="odd" required /> Lẻ</label><br />
        <input type="number" name="bet" min="1" max="\${balance}" required /> <br />
        <button type="submit">Đặt cược</button>
      </form>
      <a href="/">Trang chủ</a>
    \`);
  });
});

app.post('/play', requireLogin, (req, res) => {
  const choice = req.body.choice;
  const bet = parseInt(req.body.bet, 10);
  db.get('SELECT balance FROM users WHERE id = ?', [req.session.user.id], (err, row) => {
    if (!row || bet > row.balance) return res.send('❌ Không đủ tiền!');
    const number = Math.floor(Math.random() * 100) + 1;
    const outcome = number % 2 === 0 ? 'even' : 'odd';
    let message;
    let newBalance = row.balance;
    if (choice === outcome) {
      newBalance += bet;
      message = \`🎉 Bạn thắng! Số: \${number}\`;
    } else {
      newBalance -= bet;
      message = \`😢 Bạn thua. Số: \${number}\`;
    }
    db.run('UPDATE users SET balance = ? WHERE id = ?', [newBalance, req.session.user.id]);
    res.send(\`<!doctype html>
      <h2>\${message}</h2>
      <p>Số dư mới: <b>\${newBalance}</b></p>
      <a href="/play">Chơi lại</a> | <a href="/">Trang chủ</a>
    \`);
  });
});

// START SERVER
app.listen(PORT, () => {
  console.log(\`Server listening on port \${PORT}\`);
});
